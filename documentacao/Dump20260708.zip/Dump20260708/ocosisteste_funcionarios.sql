CREATE DATABASE  IF NOT EXISTS `ocosisteste` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `ocosisteste`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: ocosisteste
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionarios` (
  `id_funcionario` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_func` int(11) DEFAULT NULL,
  `masp` varchar(8) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `cargo_funcionario` varchar(100) NOT NULL,
  PRIMARY KEY (`id_funcionario`),
  UNIQUE KEY `masp` (`masp`),
  KEY `fk_tipo_funcionario` (`id_tipo_func`),
  CONSTRAINT `fk_tipo_funcionario` FOREIGN KEY (`id_tipo_func`) REFERENCES `tipo_func` (`id_tipo_func`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (1,1,'11111111','h1','Diretor'),(2,2,'22222222','h2','Vice'),(3,3,'33333333','h3','Coord'),(4,4,'44444444','h4','Inspetor'),(5,6,'77777777','h7','Prof'),(6,1,'67802571','$2y$10$Lskf64H3P1XRMnw/dWLD8u5SlBCoF56ANhMYHMI7HIKZE61cCGbk2','Direção'),(8,5,'12234454','$2y$10$llCTfp9RBNvS7aFIp4D5W.20TWBIJ4a8VzLpNEpLQSuXOtPDY6An.','Sec'),(9,5,'34567807','$2y$10$pVCUV2z2jnyckr8XJf6CQ.rbnpzHlz6xTy6AzPGrEij3Uz2l9lzZm','Sec'),(12,5,'90000973','$2y$10$FZp/GzlR4I064fIQ4bPSGuBbyOBCkLpH1Rogld5jkZ6N.QvCpRFp2','Sec'),(13,5,'23445556','$2y$10$2GpiLI1SsWS/EHL78Pbpaew1n0zilYXKVG2eBQJa7wRM4zI1GxRBG','Sec');
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-08 20:31:14
