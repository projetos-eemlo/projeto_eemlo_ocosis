CREATE DATABASE  IF NOT EXISTS `ocosisteste` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `ocosisteste`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: ocosisteste
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `turma`
--

DROP TABLE IF EXISTS `turma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turma` (
  `id_turma` int(11) NOT NULL AUTO_INCREMENT,
  `desc_turma` varchar(255) NOT NULL,
  `turno` varchar(50) NOT NULL,
  `ano_letivo` int(11) NOT NULL,
  `semestre_letivo` int(11) DEFAULT NULL,
  `trimestre_letivo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_turma`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turma`
--

LOCK TABLES `turma` WRITE;
/*!40000 ALTER TABLE `turma` DISABLE KEYS */;
INSERT INTO `turma` VALUES (1,'1º Ano A','Manhã',2026,1,1),(2,'1º Ano B','Manhã',2026,1,1),(3,'1º Ano C','Tarde',2026,1,1),(4,'2º Ano A','Manhã',2026,1,1),(5,'2º Ano B','Tarde',2026,1,1),(6,'3º Ano A','Manhã',2026,1,1),(7,'3º Ano B','Noite',2026,1,1),(8,'8º Ano A','Tarde',2026,1,1),(9,'8º Ano B','Tarde',2026,1,1),(10,'9º Ano A','Manhã',2026,1,1),(11,'9º Ano B','Tarde',2026,1,1),(12,'9º Ano C','Noite',2026,1,1),(13,'Técnico Info 1','Manhã',2026,1,1),(14,'Técnico Info 2','Manhã',2026,1,1),(15,'Técnico Info 3','Manhã',2026,1,1),(16,'Técnico ADM 1','Noite',2026,1,1),(17,'Técnico ADM 2','Noite',2026,1,1),(18,'EJA 1','Noite',2026,1,1),(19,'EJA 2','Noite',2026,1,1),(20,'Pré-Vestibular','Noite',2026,1,1);
/*!40000 ALTER TABLE `turma` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-08 20:31:14
